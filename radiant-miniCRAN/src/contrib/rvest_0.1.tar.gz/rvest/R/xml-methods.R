#' @export
`[.XMLNodeSet` <- function(x, i, ...) {
  structure(NextMethod(),  class = "XMLNodeSet")
}
